
# run libraries
library(dplyr)
library(emmeans)
library(forcats)
library(ggplot2)
library(ggtext)
library(gt)
library(gtExtras)
library(lubridate)
library(stringr)
library(tidyr)

##################### DATA PREPROCESSING

# read in data
yr19 <- read.csv("2019stops.csv")
yr20 <- read.csv("2020stops.csv")
yr21 <- read.csv("2021stops.csv")
yr22 <- read.csv("2022stops.csv")

# define the column names
col_names <- c("stop_type", "citation_num", "stop_outcome", "officer_gender", "officer_race",
               "officer_age", "stop_date", "stop_time", "stop_location", "stop_division", 
               "stop_beat", "driver_gender", "driver_race", "driver_age", "passenger_num", 
               "vehicle_searched", "search_reason")

# list the datasets
datasets <- list(yr19, yr20, yr21, yr22)

# rename columns for all datasets and combine them
stops <- do.call(rbind, lapply(datasets, function(df) {
  colnames(df) <- col_names
  df
}))

# pre-process the data
stops <- stops %>%
  mutate(
    
    # label the search reason
    search_reason = case_when(
      search_reason == 1 ~ "CONSENT",
      search_reason == 2 ~ "TERRY STOP/PAT DOWN",
      search_reason == 3 ~ "INCIDENT TO ARREST",
      search_reason == 4 ~ "PROBABLE CAUSE",
      search_reason == 5 ~ "OTHER",
      search_reason == 0 ~ "NOT SPECIFIED" # not really 'unknown' but not specified
    ), 
    
    # define day or night time
    stop_time_n = str_replace(stop_time, "^(\\d{1,2}:\\d{2})$", "\\1:00"),
    stop_time_n = hms::as_hms(stop_time_n),
    day_or_night = case_when(
      hour(stop_time_n) >= 6 & hour(stop_time_n) < 18 ~ "Daytime",
      TRUE ~ "Nighttime"
    ),,
    
    # whether the driver drives alone or not
    drive_alone = ifelse(passenger_num > 0, "No", "Yes"),
    
    # recode the vehicle_searched variable
    vehicle_searched = case_when(
      vehicle_searched == "YES" ~ 1,
      vehicle_searched == "NO" ~ 0
    )
  )

# filter to data that is needed
stops_n <- stops %>%
  filter(driver_race %in% c("WHITE", "BLACK"),
         officer_race %in% c("WHITE", "BLACK"),
         stop_division %in% c("2ND DIVISION", "8TH DIVISION"))


##################### EDA

# searches vs citations for driver race
search_vs_citation <- stops_n %>%
  group_by(stop_division, driver_race) %>%
  summarize(
    citation_count = n(),
    search_count = sum(vehicle_searched),
    search_rate = round(search_count/citation_count*100, 2)
  ) %>%
  pivot_longer(
    cols = c(citation_count, search_count), 
    names_to = "count_type", 
    values_to = "count"
  )

ggplot(search_vs_citation, aes(x=driver_race, y=count, fill=count_type)) +
  
  # create citation bars
  geom_bar(
    data = search_vs_citation %>% filter(count_type == "citation_count"),
    stat = "identity", 
    position = position_dodge(0), 
    fill = "#f4c1c1"
  ) +
  
  # create search bats
  geom_bar(
    data = search_vs_citation %>% filter(count_type == "search_count"),
    stat = "identity", 
    position = position_dodge(0), 
    fill = "#c74f4f"
  ) +
  
  # add annotation
  geom_text(
    data = search_vs_citation %>% filter(count_type == "search_count"),
    aes(label = paste0(search_rate, "%")),
    position = position_dodge(width = 0),
    vjust = -0.5, 
    color = "#c74f4f",
    size = 4,
    fontface= "bold"
  ) +
  facet_wrap(. ~ stop_division) +
  labs(
    title = "Comparison of <span style='color: #c74f4f;'>Search Counts</span> Relative to 
             <span style='color: #f4c1c1;'>Citation Counts</span> by Driver Race across Divisions",
    subtitle = "Percentages represent search rate",
    x = "",
    y = ""
  ) +
  scale_y_continuous(breaks = seq(0, 15000, 3000)) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(),
    plot.title = element_markdown(face="bold", size=14),
    plot.subtitle = element_text(face="italic", size=10),
    strip.text = element_text(face = "bold"),
    axis.text.x = element_text(size=10),
    axis.text.y = element_text(size=10)
  )


# searches vs citations for officer race
officer_search <- stops_n %>%
  group_by(officer_race, stop_division) %>%
  summarize(
    citation_count = n(),
    search_count = sum(vehicle_searched),
    search_rate = round(search_count/citation_count*100, 2)
  ) %>%
  pivot_longer(
    cols = c(citation_count, search_count), 
    names_to = "count_type", 
    values_to = "count"
  )

ggplot(officer_search, aes(x=officer_race, y=count, fill=count_type)) +
  
  # create citation bars
  geom_bar(
    data = officer_search %>% filter(count_type == "citation_count"),
    stat = "identity", 
    position = position_dodge(0), 
    fill = "#f4c1c1"
  ) +
  
  # create search bars
  geom_bar(
    data = officer_search %>% filter(count_type == "search_count"),
    stat = "identity", 
    position = position_dodge(0), 
    fill = "#c74f4f"
  ) +
 
  # add annotation
  geom_text(
    data = officer_search %>% filter(count_type == "search_count"),
    aes(label = paste0(search_rate, "%")),
    position = position_dodge(width = 0),
    vjust = -0.5, 
    color = "#c74f4f",
    size = 4,
    fontface= "bold"
  ) +
  facet_wrap(. ~ stop_division) +
  labs(
    title = "Comparison of <span style='color: #c74f4f;'>Search Counts</span> Relative to 
             <span style='color: #f4c1c1;'>Citation Counts</span> by Officer Race across Divisions",
    subtitle = "Percentages represent search rate",
    x = "",
    y = ""
  ) +
  scale_y_continuous(breaks = seq(0, 12000, 3000)) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(),
    plot.title = element_markdown(face="bold", size=14),
    plot.subtitle = element_text(face="italic", size=10),
    strip.text = element_text(face = "bold"),
    axis.text.x = element_text(size=10),
    axis.text.y = element_text(size=10)
  )


# compare search rates across divisions and times of the day
search_div_time <- stops_n %>%
  group_by(stop_division, officer_race, driver_race, day_or_night) %>%
  summarize(
    search_rate = round(mean(vehicle_searched)*100, 2), .groups = "drop"
  )

ggplot(search_div_time, aes(x=driver_race, y=search_rate, fill=officer_race)) +
  geom_bar(stat = "identity", position = position_dodge(), width=0.7) +
  facet_grid(day_or_night ~ stop_division) +
  labs(
    title = "Search Rates (%) by Division and Time of Day",
    x = "Driver Race",
    y = "",
    fill = "Officer Race"
  ) +
  scale_fill_manual(values = c("BLACK" = "#c74f5f","WHITE" = "#4fc7b7")) +
  scale_y_continuous(labels = scales::percent_format(scale=1)) +
  theme_bw() +
  theme(
    plot.title = element_text(size=16, face="bold", hjust=0.5), 
    axis.text.x = element_text(size=12, angle=0, hjust=0.5),
    axis.title = element_text(size=14),
    strip.text = element_text(size=12),
    legend.position = "bottom",
    legend.title = element_text(size=12),
    legend.text = element_text(size=10)
  )

# compare search rates in relation to citations
search_time_citation <- stops_n %>%
  group_by(stop_division, day_or_night, officer_race, driver_race) %>%
  summarize(
    citation_count = n(),
    search_count = sum(vehicle_searched),
    search_rate = round(search_count / citation_count * 100, 2)
  ) %>%
  pivot_longer(
    cols = c(citation_count, search_count), 
    names_to = "count_type", 
    values_to = "count"
  )

ggplot(search_time_citation, aes(x=driver_race, y=count, fill=officer_race)) +
  
  # create citation bars
  geom_bar(
    data = search_time_citation %>% filter(count_type == "citation_count"),
    stat = "identity", 
    position = position_dodge(width = 0.8),
    alpha = 0.5,
    width = 0.7
  ) +
 
  # create search bars
  geom_bar(
    data = search_time_citation %>% filter(count_type == "search_count"),
    stat = "identity", 
    position = position_dodge(width = 0.8),
    width = 0.7
  ) +
  
  # add annotation
  geom_text(
    data = search_time_citation %>% filter(count_type == "search_count"),
    aes(label = paste0(search_rate, "%")),
    position = position_dodge(width = 0.8),
    vjust = -0.5,
    size = 3,
    fontface = "bold"
  ) +
  facet_grid(day_or_night ~ stop_division) +
  labs(
    title = "Comparison of Search and Citation Counts by Officer and Driver Race across Divisions and Time of Day",
    subtitle = "Percentages represent search rates",
    x = "Driver Race",
    y = "",
    fill = "Officer Race"
  ) +
  scale_y_continuous(breaks = seq(0, 8000, 2000)) +
  scale_fill_manual(
    values = c("BLACK" = "#c74f5f",
               "WHITE" = "#4fc7b7")
  ) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(),
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(face = "italic", size = 10),
    strip.text = element_text(face = "bold"),
    axis.text.x = element_text(size = 10, hjust = 0.5),
    axis.text.y = element_text(size = 10),
    legend.position = "bottom"
  )


##################### MODELLING

# fit a logistic regression model for division 8 during daytime
div8_day_glm <- glm(
  vehicle_searched ~ driver_race*officer_race,
  family = binomial(link = "logit"),
  data = stops_n %>% 
    filter(day_or_night == "Daytime",
           stop_division == "8TH DIVISION"))

summary(div8_day_glm)

div8_day_contrast <- emmeans(
  div8_day_glm,
  specs = pairwise ~ officer_race | driver_race,
  type = "response"
)

div8_day_contrast$emmeans
div8_day_contrast$contrasts

cbind(
  as.data.frame(div8_day_contrast$emmeans),
  as.data.frame(div8_day_contrast$contrasts)
) %>%
  select(2, 1, 3:4, 10, 15) %>%
  mutate(
    driver_race = ifelse(driver_race == "BLACK", "Black Driver", "White Driver"),
    officer_race = ifelse(officer_race == "BLACK", "Black", "White"),
    prob = round(prob, 3), 
    SE = round(SE, 3),
    odds.ratio = round(odds.ratio, 2),
    p.value = round(p.value, 4)
  ) %>%
  group_by(driver_race) %>%
  gt() %>%
  gt_theme_pff()

# fit a logistic regression model for division 8 during nighttime
div8_night_glm <- glm(
  vehicle_searched ~ driver_race*officer_race,
  family = binomial(link = "logit"),
  data = stops_n %>% 
    filter(day_or_night == "Nighttime",
           stop_division == "8TH DIVISION"))

summary(div8_night_glm)

div8_night_contrast <- emmeans(
  div8_night_glm,
  specs = pairwise ~ officer_race | driver_race,
  type = "response"
)

cbind(
  as.data.frame(div8_night_contrast$emmeans),
  as.data.frame(div8_night_contrast$contrasts)
) %>%
  select(2, 1, 3:4, 10, 15) %>%
  mutate(
    driver_race = ifelse(driver_race == "BLACK", "Black Driver", "White Driver"),
    officer_race = ifelse(officer_race == "BLACK", "Black", "White"),
    prob = round(prob, 3), 
    SE = round(SE, 3),
    odds.ratio = round(odds.ratio, 2),
    p.value = round(p.value, 4)
  ) %>%
  group_by(driver_race) %>%
  gt() %>%
  gt_theme_pff()

# fit a logistic regression model for division 2 during daytime
div2_day_glm <- glm(
  vehicle_searched ~ driver_race*officer_race,
  family = binomial(link = "logit"),
  data = stops_n %>% 
    filter(day_or_night == "Daytime",
           stop_division == "2ND DIVISION"))

summary(div2_day_glm)

div2_day_contrast <- emmeans(
  div2_day_glm,
  specs = pairwise ~ officer_race | driver_race,
  type = "response"
)

div2_day_contrast$emmeans
div2_day_contrast$contrasts

cbind(
  as.data.frame(div2_day_contrast$emmeans),
  as.data.frame(div2_day_contrast$contrasts)
) %>%
  select(2, 1, 3:4, 10, 15) %>%
  mutate(
    driver_race = ifelse(driver_race == "BLACK", "Black Driver", "White Driver"),
    officer_race = ifelse(officer_race == "BLACK", "Black", "White"),
    prob = round(prob, 3), 
    SE = round(SE, 3),
    odds.ratio = round(odds.ratio, 2),
    p.value = round(p.value, 4)
  ) %>%
  group_by(driver_race) %>%
  gt() %>%
  gt_theme_pff()

# fit a logistic regression model for division 2 during nighttime
div2_night_glm <- glm(
  vehicle_searched ~ driver_race*officer_race,
  family = binomial(link = "logit"),
  data = stops_n %>% 
    filter(day_or_night == "Nighttime",
           stop_division == "2ND DIVISION"))

summary(div2_night_glm)

div2_night_contrast <- emmeans(
  div2_night_glm,
  specs = pairwise ~ officer_race | driver_race,
  type = "response"
)

cbind(
  as.data.frame(div2_night_contrast$emmeans),
  as.data.frame(div2_night_contrast$contrasts)
) %>%
  select(2, 1, 3:4, 10, 15) %>%
  mutate(
    driver_race = ifelse(driver_race == "BLACK", "Black Driver", "White Driver"),
    officer_race = ifelse(officer_race == "BLACK", "Black", "White"),
    prob = round(prob, 3), 
    SE = round(SE, 3),
    odds.ratio = round(odds.ratio, 2),
    p.value = round(p.value, 4)
  ) %>%
  group_by(driver_race) %>%
  gt() %>%
  gt_theme_pff()
